var intGetal1;
var intGetal2;