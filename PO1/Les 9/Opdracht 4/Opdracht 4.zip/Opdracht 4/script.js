function wisselKleur() {
    document.getElementById("homeKnop").style.backgroundColor="orange";
    document.getElementById("overmijKnop").style.backgroundColor="black";
    document.getElementById("portfolioKnop").style.backgroundColor="black";
    document.getElementById("image").src="image_2.jpg";
}

function veranderKleur() {
    document.getElementById("homeKnop").style.backgroundColor="black";
    document.getElementById("overmijKnop").style.backgroundColor="orange";
    document.getElementById("portfolioKnop").style.backgroundColor="black";
    document.getElementById("image").src="image_3.jpg";

} 

function maakandersKnop() {
    document.getElementById("homeKnop").style.backgroundColor="black";
    document.getElementById("overmijKnop").style.backgroundColor="black";
    document.getElementById("portfolioKnop").style.backgroundColor="orange";
    document.getElementById("image").src="image_4.jpg";

}