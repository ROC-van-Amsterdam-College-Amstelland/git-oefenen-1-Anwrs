function wisselKleur() {
    document.getElementById("homeKnop").style.backgroundColor="orange";
    document.getElementById("overmijKnop").style.backgroundColor="black";
    document.getElementById("portfolioKnop").style.backgroundColor="black";
}

function veranderKleur() {
    document.getElementById("homeKnop").style.backgroundColor="black";
    document.getElementById("overmijKnop").style.backgroundColor="orange";
    document.getElementById("portfolioKnop").style.backgroundColor="black";
} 

function maakandersKnop() {
    document.getElementById("homeKnop").style.backgroundColor="black";
    document.getElementById("overmijKnop").style.backgroundColor="black";
    document.getElementById("portfolioKnop").style.backgroundColor="orange";
}