function clickMyButton() {
var number1= prompt ("myNumber1") ;
var number2= prompt ("myNumber2") ;

       
if  (number1 >= number2) {
       document.getElementById("myCalculation").innerHTML = "groter"
        document.getElementById("myCalculation").style.fontSize="70px";

} else {
    document.getElementById("myCalculation").innerHTML = "kleiner"
    document.getElementById("myCalculation").style.fontSize="25px";
}
 
        
    








}