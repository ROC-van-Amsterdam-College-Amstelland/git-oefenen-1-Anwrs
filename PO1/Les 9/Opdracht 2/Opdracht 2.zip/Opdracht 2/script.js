function clickMyButton() {
var number1= prompt ("myNumber1") ;
var number2= prompt ("myNumber2") ;

document.getElementById("myCalculation").innerHTML= number1 * number2;
}
