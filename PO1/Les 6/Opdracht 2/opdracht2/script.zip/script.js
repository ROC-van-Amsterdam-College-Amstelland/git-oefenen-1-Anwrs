var wordt1 = prompt("Vul hier tekst in");

if (wordt1 == String);(
    document.getElementById("main").style.backgroundColor = "red"
)
if (wordt1 == Number);(
    document.getElementById("main").style.backgroundColor = "green"
)

var tekst ="hallo"
if (typeof(tekst) == String)(
    document.getElementById("main").style.backgroundColor = "green"
)

var tekst ="4"
if (typeof(tekst) == Number)(
    document.getElementById("main").style.backgroundColor = "green"
)