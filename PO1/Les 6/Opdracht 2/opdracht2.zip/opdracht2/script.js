//schrijf hier je Javascript code
//maak hier je variabelen


//maak hier je condities
//gebruik type of om het type te bepalen


