var myDinner = prompt("Wat wil je eten?");
var myAmount = prompt("Hoeveel wil je eten?");
var myPrice = 4.95;
alert(myAmount * myPrice);