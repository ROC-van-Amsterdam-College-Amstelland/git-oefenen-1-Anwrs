window.onload = function() {

    changeElm();

    function changeElm() {
        var elmValue = "ik vul dit element met javascript";
        document.getElementById("myFirstDiv").innerHTML = elmValue;
    }

}