function toonTekst() {
    var voornaam="Anouar"
    var achternaam=" El Ghazaoui"
    document.getElementById("tekst").innerHTML= voornaam +  achternaam;
    document.getElementById("tekst").style.fontSize = "80px";
}